zip -r mysubmission.zip *
