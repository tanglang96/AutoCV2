zip -r code.zip *
