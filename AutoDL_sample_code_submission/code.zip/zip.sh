zip -r code.zip *
