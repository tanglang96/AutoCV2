zip -r submit.zip *
